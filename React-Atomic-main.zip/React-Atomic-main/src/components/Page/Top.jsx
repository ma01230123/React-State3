import styled from "styled-components";

export const Top = () => {
  return(
    <>
      <STop >
        <p>top</p>
      </STop >
    </>
  );
};

const STop = styled.div`
  text-align: center;


`;